
//  Copyright © 2018年 adong666666. All rights reserved.
//

import UIKit
import HandyJSON

struct someachievements: HandyJSON {
    var content: String = ""
    var bury_count: Int = 0
    var ansid: String = ""
    var show_time: String = ""
    var wap_url: String = ""
    var schema: String = ""
    var is_show_bury: Bool = false
    var title: String = ""
    var is_delete: Int = 0
    var is_digg: Bool = false
    var is_buryed: Bool = false
    var digg_count: Int = 0
    var ans_url: String = ""
    var tag_name: String = ""
    var qid: String = ""
    var nice_ans_count: Int = 0
    var tag_id: Int = 0
}
