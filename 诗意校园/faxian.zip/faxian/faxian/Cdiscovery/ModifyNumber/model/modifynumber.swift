
import UIKit
import HandyJSON

struct modifynumber: HandyJSON {
    var content_unescape: String = ""
    
    var thread_id: Int = 0
    
    var show_tips: String = ""
    
    var thread_id_str: String = ""
    
    var rich_content: String = ""
    
    var show_origin = false
    
    var open_url: String = ""
}
